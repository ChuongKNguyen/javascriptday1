// part 1
var a=10, b=13;
console.log(a+b);

var c="hello";
var d="world";

alert(c+" "+d);
// part 2
var user = {firstName: 'Chuong', lastName: 'Nguyen', birthday: '10/12/1989', interest: ["Drawing", "Design", "Architecture"]};

console.log("Me", user.firstName, user.lastName);
console.log("DOB", user.birthday);
console.log("favorite 1", user.interest[0]);
console.log("favorite 2", user.interest[1]);
console.log("favorite 3", user.interest[2]);

// part 3
function check(a){
	if (a<100){
	alert("your variable is smaller than 100 and your variable is ", a)
} else {
	alert("your variable is bigger than 100 and your variable is ", a)
}

}
// part 5
function checkString(word){
  alert(typeof word)
}

// part 6
function showyourName(name){
	console.log("Your name is ", name)
}

// part 7
function printsomething(){
	console.log("It is what it is")
}

// part 8
function chooseDoor(door){
	if (door==1){
		alert("You pick door number"+ door+" and you are awesome")
	}
	else if (door==2){
		alert("You pick door number"+ door+" and you are bright")
	}
	else if (door==3){
		alert("You pick door number"+ door+" and it is not the door that you suppose to pick, pick another one")
	}
}
